# lab-2-ia

## Bayesian Network Python Implementation

### Author: Roberto Rios

### Version: Alpha 0.0.1 (not even functional)

first upload to pip just, still finishing it
Dont use untill this description includes examples
